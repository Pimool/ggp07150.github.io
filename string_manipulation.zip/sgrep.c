#include <stdio.h>
#include <stdlib.h>
#include <string.h> /* for skeleton code */
#include <unistd.h> /* for getopt */
#include "str.h"

#define MAX_STR_LEN 1023

#define FALSE 0
#define TRUE  1

/*
 * Fill out your own functions here (If you need) 
 */
int check(char* line, const char* goal){
	
	char goal_starcheck[MAX_STR_LEN+2];
	while (*goal=='*'){
		goal++;
	}
	if (*goal=='\0'){
		return TRUE;
	}
	else{
		int i=0;
		while((*goal!='*')&&(*goal!='\0')){
			goal_starcheck[i]=*goal;
			i++;
			goal++;
		}
		goal_starcheck[i] = '\0';
		//printf("i is %d\n",i);
		//printf("goal_starcheck is %s\n",goal_starcheck);
		//printf("line is %s\n",line);
		char* checker=StrFindStr(line, (const char*)goal_starcheck);
		if (checker==NULL){
			//printf("checker is %s\n", checker);
			return FALSE;
		}
		else{
			//printf("checker is %s\n", checker);
			int len_goal_starcheck=
			StrGetLength((const char*)goal_starcheck);
			int j=0;
			for (j=0; j<len_goal_starcheck; j++){
				checker++;
			}
			//printf("checker is %s after shifting\n" , checker);
			return (check(checker, goal));
		}
	}
}

/*--------------------------------------------------------------------*/
/* PrintUsage()
   print out the usage of the Simple Grep Program                     */
/*--------------------------------------------------------------------*/
void 
PrintUsage(const char* argv0) 
{
  const static char *fmt = 
	  "Simple Grep (sgrep) Usage:\n"
	  "%s pattern [stdin]\n";

  printf(fmt, argv0);
}
/*-------------------------------------------------------------------*/
/* SearchPattern()
   Your task:
   1. Do argument validation 
   - String or file argument length is no more than 1023
   - If you encounter a command-line argument that's too long, 
   print out "Error: argument is too long"
   
   2. Read the each line from standard input (stdin)
   - If you encounter a line larger than 1023 bytes, 
   print out "Error: input line is too long" 
   - Error message should be printed out to standard error (stderr)
   
   3. Check & print out the line contains a given string (search-string)
      
   Tips:
   - fgets() is an useful function to read characters from file. Note 
   that the fget() reads until newline or the end-of-file is reached. 
   - fprintf(sderr, ...) should be useful for printing out error
   message to standard error

   NOTE: If there is any problem, return FALSE; if not, return TRUE  */
/*-------------------------------------------------------------------*/
int
SearchPattern(const char *pattern)
{
  char buf[MAX_STR_LEN + 2]; 
  int len;
  if (StrGetLength(pattern)>MAX_STR_LEN){
  	return FALSE;
  }
  /* 
   *  TODO: check if pattern is too long
   */


  
  /* Read one line at a time from stdin, and process each line */
  while (fgets(buf, sizeof(buf), stdin)) {
	  
    /* check the length of an input line */
    if ((len = StrGetLength(buf)) > MAX_STR_LEN) {
      fprintf(stderr, "Error: input line is too long\n");
      return FALSE;
    }
	else{
		if (check(buf, pattern)){
			printf("%s",buf);
		}
	}
    /* TODO: fill out this function */
  }
   
  return TRUE;
}
/*-------------------------------------------------------------------*/
int 
main(const int argc, const char *argv[]) 
{
  /* Do argument check and parsing */
  if (argc < 2) {
	  fprintf(stderr, "Error: argument parsing error\n");
	  PrintUsage(argv[0]);
	  return (EXIT_FAILURE);
  }

  return SearchPattern(argv[1]) ? EXIT_SUCCESS:EXIT_FAILURE;
}
