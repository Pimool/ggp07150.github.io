#include <assert.h> /* to use assert() */
#include <stdio.h>
#include <stdlib.h> /* for strtol() */
#include "str.h"
#include <limits.h>
#include <ctype.h>

/* Your task is: 
   1. Rewrite the body of "Part 1" functions - remove the current
      body that simply calls the corresponding C standard library
      function.
   2. Write appropriate comment per each function
*/

/* Part 1 */
/*------------------------------------------------------------------------*/
size_t StrGetLength(const char* pcSrc)
{
  const char *pcEnd;
  assert(pcSrc); /* NULL address, 0, and FALSE are identical. */
  pcEnd = pcSrc;
	
  while (*pcEnd) /* null character and FALSE are identical. */
    pcEnd++;

  return (size_t)(pcEnd - pcSrc);
}

/*------------------------------------------------------------------------*/
char *StrCopy(char *pcDest, const char* pcSrc)
{
  /* TODO: fill this function */
  assert(pcDest);
  assert(pcSrc);
  char* s=pcDest;
  int len=StrGetLength(pcSrc);
  int i=0;
  for(i=0; i<len; i++){
  	*s=*pcSrc;
  	s++;
  	pcSrc++;
  }
  *s = '\0';
  return(pcDest);
  //return strcpy(pcDest, pcSrc);
}

/*------------------------------------------------------------------------*/
int StrCompare(const char* pcS1, const char* pcS2)
{
  /* TODO: fill this function */
  assert(pcS1);
  assert(pcS2);
  while (((*pcS1)!='\0') || ((*pcS2)!='\0')){
  	if (*pcS1!=*pcS2){
  		return ((*pcS1>*pcS2)*2-1);
	  }
	else {
		pcS1++;
		pcS2++;
	}
  }
  return 0;
  //return strcmp(pcS1, pcS2);
}
/*------------------------------------------------------------------------*/
char *StrFindChr(const char* pcHaystack, int c)
{
  /* TODO: fill this function */
  assert(pcHaystack);
  int i=0;
  int len=StrGetLength(pcHaystack);
  if (c=='\0'){
  	for (i=0; i<len; i++){
  		if (*pcHaystack==c){
  			return (char*)pcHaystack;
		}
		else{
			pcHaystack++;
		}
  	}
  	return (char*)pcHaystack;
  }
  else{
  	for (i=0; i<len; i++){
  		if (*pcHaystack==c){
  			return (char*)pcHaystack;
		}
		else{
			pcHaystack++;
		}
  	}
  	return NULL;
  }
}
  //return strchr(pcHaystack, c);

/*------------------------------------------------------------------------*/
char *StrFindStr(const char* pcHaystack, const char *pcNeedle)
{
  /* TODO: fill this function */
  assert(pcHaystack);
  assert(pcNeedle);
  if (*pcNeedle=='\0'){
  	return (char*)pcHaystack;
  }
  else {}
  char* want_to_check=StrFindChr(pcHaystack,*pcNeedle);
  int len=StrGetLength(pcNeedle);
  if (want_to_check==NULL){
  	return NULL;
  }
  int i=0;
  for (i=1; i<len; i++){
  	want_to_check++;
  	pcNeedle++;
  	if (*want_to_check!=*pcNeedle){
  		int j=0;
  		for (j=0; j<i; j++){
  			pcNeedle--;
		  }
  		want_to_check=StrFindChr(want_to_check,*pcNeedle);
  		i=0;
  		if (want_to_check==NULL){
  			return NULL;
		  }
	  }
  }
  int k=0;
  for (k=1; k<len; k++){
  	want_to_check--;
  }
  return want_to_check;
 
  //return strstr(pcHaystack, pcNeedle);
}
/*------------------------------------------------------------------------*/
char *StrConcat(char *pcDest, const char* pcSrc)
{
  /* TODO: fill this function */
  assert(pcDest);
  assert(pcSrc);
  char* new=pcDest;
  int i=0;
  int len_Dest=StrGetLength(pcDest);
  for (i=0; i<len_Dest; i++){
	*new=*pcDest;
  	new++;
	pcDest++;
  }
  int j=0;
  int len_Src=StrGetLength(pcSrc);
  for (j=0; j<len_Src; j++){
	*new=*pcSrc;
	pcSrc++;
	new++;
  }
	*new='\0';
  int k=0;
  for (k=0; k<len_Dest+len_Src; k++){
  	new--;
  }
  
  return new;
  
  //return strcat(pcDest, pcSrc);
}

/*------------------------------------------------------------------------*/
long int StrToLong(const char *nptr, char **endptr, int base)
{
  /* handle only when base is 10 */
  if (base != 10) return 0;

  /* TODO: fill this function */
  assert(nptr);
  long int x = 0;
  long int temp;
  while (*nptr && isspace((int)(*nptr))) {			//��ĭ 
  	nptr++;
  }
  if (*nptr=='+'){
  	nptr++;
  	while (*nptr && isdigit((int)(*nptr))) {
		temp = *nptr - '0';
    	x = 10 * x + temp;
    	if (x<0){
    		return LONG_MAX;
			}
    	nptr++;
	}
  }
  else if (*nptr=='-'){
  	nptr++;
  	while (*nptr && isdigit((int)*nptr)) {
		temp = *nptr - '0';
    	x = 10 * x - temp;
    	if (x>0){
    		return LONG_MIN;
		}
    	nptr++;
  	}
  }	
  else {
  	while (*nptr && isdigit((int)(*nptr))) {
		temp = *nptr - '0';
    	x = 10 * x + temp;
    	if (x<0){
    		return LONG_MAX;
		}
    	nptr++;
	}
  }
  if (endptr!=NULL){
  	*endptr=(char*) nptr;
  }	
  return x;
  
  //return strtol(nptr, endptr, 10);
}
