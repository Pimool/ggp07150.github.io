SEX = c(1, 2)
Height = c(1:10)

install.packages("dplyr")
library(dplyr)

df = data.frame(SEX, Height)

df
something = distinct(df, SEX)
typeof(something)
something_vector = unlist(something, recursive = TRUE, use.names = FALSE)

something_vector[1]

possibility = which(df$SEX == 1)
possibility

typeof(possibility)

df[SEX==1]
