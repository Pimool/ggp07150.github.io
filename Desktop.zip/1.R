library(dplyr)
install.packages("gmp")
library(gmp)

data = BIG_2011_12_in

# 각 column에서 나오는 모든 값들을 하나씩 뽑아 vector로 저장

SEX_TP_CD_value = unlist(distinct(data, SEX_TP_CD), recursive = TRUE, use.names = FALSE)
age_cat_in_value = unlist(distinct(data, age_cat_in), recursive = TRUE, use.names = FALSE)
DGSBJT_CD_value = unlist(distinct(data, DGSBJT_CD), recursive = TRUE, use.names = FALSE)
CL_CD_value = unlist(distinct(data, CL_CD), recursive = TRUE, use.names = FALSE)
SIDO_CD_value = unlist(distinct(data, SIDO_CD), recursive = TRUE, use.names = FALSE)
GNL_NM_CD_value = unlist(distinct(data, GNL_NM_CD), recursive = TRUE, use.names = FALSE)
MSICK_CD_value = unlist(distinct(data, MSICK_CD), recursive = TRUE, use.names = FALSE)

len_SEX = length(SEX_TP_CD_value)
len_age = length(age_cat_in_value)
len_DGSBJT = length(DGSBJT_CD_value)
len_CL = length(CL_CD_value)
len_SIDO = length(SIDO_CD_value)
len_GNL = length(GNL_NM_CD_value)
len_MSICK = length(MSICK_CD_value)

# num_cases = len_SEX
# num_cases = num_cases * len_age
# num_cases = num_cases * len_DGSBJT
# num_cases = num_cases * len_CL
# num_cases = num_cases * len_SIDO
# num_cases = num_cases * len_GNL
# num_cases = num_cases * len_MSICK
num_cases = as.numeric(len_SEX*len_age*len_DGSBJT*len_CL*len_SIDO*len_GNL)
num_cases = num_cases * len_MSICK




JID = c()

for (case in num_cases){
  assign(paste0("data", 1:num_cases), data.frame(JID))
}