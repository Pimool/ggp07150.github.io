#install.packages("dplyr")
library(dplyr)

#col1 = rep(1, 60)
col2 = rep(c(1:2), 30)
col3 = rep(c(1:3), 20)
#col4 = rep(c(1:4), 15)
#col5 = rep(c(1:5), 12)
#col6 = rep(c(1:6), 10)
JID = c(1:60)

col2 = sample(col2)
col3 = sample(col3)
JID = sample(JID)

data = data.frame(col2, col3, JID)
data

#col1_value = unlist(distinct(data, col1), recursive = TRUE, use.names = FALSE)
col2_value = unlist(distinct(data, col2), recursive = TRUE, use.names = FALSE)
col3_value = unlist(distinct(data, col3), recursive = TRUE, use.names = FALSE)
#col4_value = unlist(distinct(data, col4), recursive = TRUE, use.names = FALSE)
#col5_value = unlist(distinct(data, col5), recursive = TRUE, use.names = FALSE)
#col6_value = unlist(distinct(data, col6), recursive = TRUE, use.names = FALSE)

JID_vector = c()

cnt = 0

for (i in col2_value){
  for (j in col3_value){
    
    sets = subset(data, col2 == i & col3 == j)
    cnt+=1
    JID_vector = subset(sets, select = JID)
    message("JID_Vector = ", JID_vector)
    
  }
}
